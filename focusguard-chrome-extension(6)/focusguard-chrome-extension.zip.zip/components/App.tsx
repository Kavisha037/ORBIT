import React, { useState, useEffect, useCallback } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { SessionStatus, ActivityType } from '../types';
import { BLOCKED_SITES, GEMINI_MOTIVATION_PROMPT } from '../constants';
import { getMotivation } from '../services/geminiService';
import { WebcamVerifier } from './WebcamVerifier';
import { YouTubeTracker } from './YouTubeTracker';
import { CodingTracker } from './CodingTracker';
import { FocusWidget } from './FocusWidget';
import { ExtensionExport } from './ExtensionExport';
import { Shield, PlayCircle, Code2, Lock, ArrowRight, LayoutDashboard, BrainCircuit } from 'lucide-react';

const MainApp = () => {
  const [sessionStatus, setSessionStatus] = useState<SessionStatus>(SessionStatus.IDLE);
  const [activityType, setActivityType] = useState<ActivityType>(ActivityType.VIDEO);
  const [timer, setTimer] = useState(0);
  const [motivation, setMotivation] = useState("");
  
  // Verification States
  const [isFaceVerified, setIsFaceVerified] = useState(true);
  const [isActivityVerified, setIsActivityVerified] = useState(false);
  const [warningMessage, setWarningMessage] = useState<string | undefined>(undefined);

  // Configuration
  const [useFaceCam, setUseFaceCam] = useState(false);

  // Timer Logic
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (sessionStatus === SessionStatus.ACTIVE) {
      interval = setInterval(() => {
        setTimer(prev => prev + 1);
        // Occasionally fetch motivation
        if (Math.random() < 0.01) { // 1% chance per second
           getMotivation().then(setMotivation);
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [sessionStatus]);

  // Master Verification Logic
  useEffect(() => {
    if (sessionStatus === SessionStatus.IDLE) return;

    let warnings = [];
    let shouldPause = false;

    if (useFaceCam && !isFaceVerified) {
      warnings.push("Face not detected! Look at screen.");
      shouldPause = true;
    }

    if (!isActivityVerified) {
      warnings.push(activityType === ActivityType.VIDEO ? "Video paused or hidden." : "No coding activity.");
      shouldPause = true;
    }

    if (shouldPause) {
      setSessionStatus(SessionStatus.PAUSED);
      setWarningMessage(warnings.join(" "));
    } else if (sessionStatus === SessionStatus.PAUSED && warnings.length === 0) {
      // Auto resume if everything is clear
      setSessionStatus(SessionStatus.ACTIVE);
      setWarningMessage(undefined);
    } else {
        setWarningMessage(undefined);
    }

  }, [isFaceVerified, isActivityVerified, sessionStatus, useFaceCam, activityType]);


  const startSession = () => {
    setSessionStatus(SessionStatus.ACTIVE);
    setIsActivityVerified(false); // Assume false until first heartbeat
    setTimer(0);
    getMotivation().then(setMotivation);
  };

  const stopSession = () => {
    setSessionStatus(SessionStatus.IDLE);
    setTimer(0);
    setWarningMessage(undefined);
  };

  return (
    <div className="min-h-screen bg-dark-950 text-slate-200 font-sans selection:bg-brand-500 selection:text-white">
      {/* Navigation / Header */}
      <nav className="border-b border-slate-800 bg-dark-900/50 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-8 h-8 text-brand-500" />
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-400 to-indigo-400">
              FocusGuard
            </span>
          </div>
          <div className="flex items-center gap-4">
             {sessionStatus !== SessionStatus.IDLE && (
                 <button onClick={stopSession} className="px-4 py-2 text-sm font-medium text-red-400 hover:bg-red-950/30 rounded-lg transition-colors">
                    End Session
                 </button>
             )}
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {sessionStatus === SessionStatus.IDLE ? (
          /* DASHBOARD VIEW */
          <div className="space-y-12 animate-fade-in">
            <div className="text-center space-y-4">
              <h1 className="text-5xl font-extrabold tracking-tight text-white sm:text-6xl">
                Master Your <span className="text-brand-500">Focus</span>
              </h1>
              <p className="max-w-2xl mx-auto text-xl text-slate-400">
                The only extension that verifies you're actually working. Blocks distractions, tracks face & activity, and uses AI to keep you locked in.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div 
                onClick={() => { setActivityType(ActivityType.VIDEO); startSession(); }}
                className="group relative bg-dark-900 border border-slate-800 hover:border-brand-500 rounded-2xl p-8 cursor-pointer transition-all hover:shadow-2xl hover:shadow-brand-900/20 hover:-translate-y-1"
              >
                <div className="absolute top-4 right-4 p-2 bg-slate-800 rounded-full group-hover:bg-brand-500 transition-colors">
                  <PlayCircle className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Video Learning</h3>
                <p className="text-slate-400 mb-6">Learn from YouTube with strict anti-cheat: Playback, audio, and visibility verification.</p>
                <div className="text-brand-400 flex items-center gap-2 font-medium">Start Session <ArrowRight className="w-4 h-4" /></div>
              </div>

              <div 
                onClick={() => { setActivityType(ActivityType.CODING); startSession(); }}
                className="group relative bg-dark-900 border border-slate-800 hover:border-purple-500 rounded-2xl p-8 cursor-pointer transition-all hover:shadow-2xl hover:shadow-purple-900/20 hover:-translate-y-1"
              >
                 <div className="absolute top-4 right-4 p-2 bg-slate-800 rounded-full group-hover:bg-purple-500 transition-colors">
                  <Code2 className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Coding Mode</h3>
                <p className="text-slate-400 mb-6">Integrates with VS Code to ensure you are actually writing code, not just staring at the screen.</p>
                <div className="text-purple-400 flex items-center gap-2 font-medium">Start Session <ArrowRight className="w-4 h-4" /></div>
              </div>
            </div>

             <div className="max-w-2xl mx-auto flex items-center justify-center gap-4 py-4">
                <label className="flex items-center gap-3 p-4 border border-slate-800 rounded-lg cursor-pointer hover:bg-slate-900 transition-colors">
                   <div className={`w-5 h-5 rounded border flex items-center justify-center ${useFaceCam ? 'bg-brand-500 border-brand-500' : 'border-slate-600'}`}>
                      {useFaceCam && <div className="w-2 h-2 bg-white rounded-full" />}
                   </div>
                   <input type="checkbox" checked={useFaceCam} onChange={e => setUseFaceCam(e.target.checked)} className="hidden" />
                   <span className="text-slate-300 font-medium">Enable Face Verification (Experimental)</span>
                </label>
             </div>

            <ExtensionExport />
          </div>
        ) : (
          /* ACTIVE SESSION VIEW */
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: Main Activity */}
            <div className="lg:col-span-2 space-y-6">
               <div className="bg-dark-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                       {activityType === ActivityType.VIDEO ? <PlayCircle className="text-brand-500" /> : <Code2 className="text-purple-500" />}
                       {activityType === ActivityType.VIDEO ? "Video Learning Room" : "Coding Workspace"}
                    </h2>
                    <span className="px-3 py-1 bg-slate-800 rounded-full text-xs font-mono text-slate-400">
                      Session ID: #8X92-FD
                    </span>
                  </div>

                  {activityType === ActivityType.VIDEO ? (
                    <YouTubeTracker 
                      videoId="jfKfPfyJRdk" // Lofi Girl Radio or similar educational video
                      onActivityUpdate={setIsActivityVerified} 
                      isActive={sessionStatus === SessionStatus.ACTIVE}
                    />
                  ) : (
                    <CodingTracker 
                      isActive={sessionStatus !== SessionStatus.PAUSED}
                      onActivityUpdate={setIsActivityVerified} 
                    />
                  )}
               </div>

               {/* AI Motivation Card */}
               <div className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 border border-indigo-500/30 rounded-xl p-6 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                     <BrainCircuit className="w-24 h-24" />
                  </div>
                  <h3 className="text-indigo-300 font-bold mb-2 flex items-center gap-2">
                    <BrainCircuit className="w-4 h-4" /> AI Coach
                  </h3>
                  <p className="text-lg font-medium text-white italic">"{motivation}"</p>
               </div>
            </div>

            {/* Right Column: Controls & Verification */}
            <div className="space-y-6">
               <div className="bg-dark-900 border border-slate-800 rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-white mb-4">Verification Station</h3>
                  
                  <div className="space-y-6">
                     <WebcamVerifier 
                       isActive={useFaceCam} 
                       onVerificationUpdate={setIsFaceVerified} 
                     />
                     
                     <div className="space-y-3">
                        <div className="flex justify-between items-center text-sm">
                           <span className="text-slate-400">Face Check</span>
                           <span className={isFaceVerified || !useFaceCam ? "text-green-400 font-bold" : "text-red-500 font-bold"}>
                             {useFaceCam ? (isFaceVerified ? 'PASS' : 'FAIL') : 'DISABLED'}
                           </span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                           <span className="text-slate-400">Activity Check</span>
                           <span className={isActivityVerified ? "text-green-400 font-bold" : "text-red-500 font-bold"}>
                             {isActivityVerified ? 'PASS' : 'FAIL'}
                           </span>
                        </div>
                     </div>
                  </div>
               </div>

               <div className="bg-dark-900 border border-slate-800 rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-white mb-4">Blocked Distractions</h3>
                  <div className="space-y-2">
                     {BLOCKED_SITES.slice(0, 4).map(site => (
                       <div key={site.id} className="flex items-center gap-3 p-2 bg-slate-950/50 rounded border border-slate-800/50 opacity-60">
                          <Lock className="w-3 h-3 text-red-500" />
                          <span className="text-sm text-slate-400 font-mono strike-through">{site.url}</span>
                       </div>
                     ))}
                     <div className="text-xs text-center text-slate-500 pt-2">
                        + {BLOCKED_SITES.length - 4} others blocked by extension
                     </div>
                  </div>
               </div>
            </div>
          </div>
        )}
      </main>

      <FocusWidget 
        status={sessionStatus} 
        activityType={activityType} 
        seconds={timer} 
        message={warningMessage}
      />
      
      {/* Route Handling for "Redirect" Simulation */}
      <Routes>
         <Route path="/blocked" element={<BlockedPage />} />
      </Routes>
    </div>
  );
};

// Simple blocked page component to simulate the extension redirect
const BlockedPage = () => (
  <div className="fixed inset-0 z-[100] bg-dark-950 flex flex-col items-center justify-center p-4">
     <Shield className="w-24 h-24 text-brand-500 mb-6" />
     <h1 className="text-4xl font-bold text-white mb-4">Focus Mode is ON</h1>
     <p className="text-xl text-slate-400 mb-8">This site is blocked. Let's get back to learning.</p>
     <a href="/" className="px-6 py-3 bg-brand-600 hover:bg-brand-500 text-white rounded-lg font-bold transition-colors">
       Return to Session
     </a>
  </div>
);


const App = () => {
  return (
    <HashRouter>
       <Routes>
         <Route path="*" element={<MainApp />} />
       </Routes>
    </HashRouter>
  );
};

export default App;