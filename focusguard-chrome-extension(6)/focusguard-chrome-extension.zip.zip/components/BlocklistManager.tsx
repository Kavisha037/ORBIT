import React, { useState } from 'react';
import { BlockedSite } from '../types';
import { Trash2, Plus, ShieldAlert } from 'lucide-react';

interface BlocklistManagerProps {
  sites: BlockedSite[];
  onAdd: (url: string) => void;
  onRemove: (id: string) => void;
}

export const BlocklistManager: React.FC<BlocklistManagerProps> = ({ sites, onAdd, onRemove }) => {
  const [newUrl, setNewUrl] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (newUrl.trim()) {
      onAdd(newUrl.trim());
      setNewUrl('');
    }
  };

  return (
    <div className="bg-dark-900 border border-slate-800 rounded-2xl p-6">
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <ShieldAlert className="w-5 h-5 text-red-500" />
        Custom Blocklist
      </h3>
      
      <form onSubmit={handleAdd} className="flex gap-2 mb-6">
        <input
          type="text"
          value={newUrl}
          onChange={(e) => setNewUrl(e.target.value)}
          placeholder="e.g. facebook.com"
          className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-brand-500"
        />
        <button 
          type="submit"
          className="px-4 py-2 bg-slate-800 hover:bg-brand-600 text-white rounded-lg transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Add
        </button>
      </form>

      <div className="space-y-2 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
        {sites.map(site => (
          <div key={site.id} className="flex items-center justify-between p-3 bg-slate-950/50 rounded-lg border border-slate-800 hover:border-slate-700 transition-all group">
            <span className="text-sm text-slate-300 font-mono">{site.url}</span>
            <button 
              onClick={() => onRemove(site.id)}
              className="p-2 text-slate-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
              title="Remove from blocklist"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ))}
        {sites.length === 0 && (
          <p className="text-center text-slate-600 text-sm py-4">No sites blocked. You're living on the edge!</p>
        )}
      </div>
    </div>
  );
};
