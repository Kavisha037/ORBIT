import React, { useState, useEffect } from 'react';
import { Terminal, Activity, Code } from 'lucide-react';
import { CODING_TIMEOUT_MS } from '../constants';

interface CodingTrackerProps {
  onActivityUpdate: (isActive: boolean) => void;
  isActive: boolean;
}

export const CodingTracker: React.FC<CodingTrackerProps> = ({ onActivityUpdate, isActive }) => {
  const [lastHeartbeat, setLastHeartbeat] = useState<number>(Date.now());
  const [isIdle, setIsIdle] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  // Timer to check for idle status
  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      const now = Date.now();
      const idle = now - lastHeartbeat > CODING_TIMEOUT_MS;
      setIsIdle(idle);
      onActivityUpdate(!idle);
    }, 1000);

    return () => clearInterval(interval);
  }, [lastHeartbeat, isActive, onActivityUpdate]);

  const simulateHeartbeat = () => {
    const now = Date.now();
    setLastHeartbeat(now);
    setIsIdle(false);
    onActivityUpdate(true);
    setLogs(prev => [`[${new Date().toLocaleTimeString()}] Received heartbeat from VS Code...`, ...prev].slice(0, 5));
  };

  return (
    <div className="w-full bg-[#1e1e1e] rounded-xl border border-slate-700 overflow-hidden shadow-2xl">
      <div className="bg-[#252526] p-3 flex justify-between items-center border-b border-[#333]">
        <div className="flex items-center gap-2 text-blue-400">
          <Code className="w-4 h-4" />
          <span className="text-sm font-mono font-bold">VS Code Integration</span>
        </div>
        <div className={`w-3 h-3 rounded-full ${isIdle ? 'bg-red-500' : 'bg-green-500 animate-pulse'}`} />
      </div>

      <div className="p-6 flex flex-col items-center justify-center min-h-[200px] gap-6">
        {isIdle ? (
          <div className="text-center">
            <Activity className="w-12 h-12 text-red-500 mx-auto mb-2 opacity-50" />
            <h3 className="text-lg font-semibold text-slate-300">No Coding Activity Detected</h3>
            <p className="text-slate-500 text-sm">Session paused due to inactivity.</p>
          </div>
        ) : (
          <div className="text-center">
            <Terminal className="w-12 h-12 text-brand-500 mx-auto mb-2" />
            <h3 className="text-lg font-semibold text-white">Coding in Progress</h3>
            <p className="text-brand-400 text-xs font-mono mt-1">Listening for extension events...</p>
          </div>
        )}

        <div className="w-full max-w-md bg-black rounded p-2 font-mono text-xs text-green-500 h-24 overflow-hidden opacity-80">
          {logs.map((log, i) => <div key={i}>{log}</div>)}
          {logs.length === 0 && <div className="text-slate-600">Waiting for connection...</div>}
        </div>

        <button 
          onClick={simulateHeartbeat}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-sm transition-colors flex items-center gap-2 shadow-lg shadow-blue-900/20"
        >
          <Activity className="w-4 h-4" />
          Simulate Typing / Heartbeat
        </button>
        <p className="text-xs text-slate-500 max-w-xs text-center">
          * In a real deployment, this receives webhooks from the installed VS Code Extension.
        </p>
      </div>
    </div>
  );
};