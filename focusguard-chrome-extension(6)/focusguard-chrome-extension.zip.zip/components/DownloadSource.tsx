import React from 'react';
import JSZip from 'jszip';
import saveAs from 'file-saver';
import { Package } from 'lucide-react';

// Definitions for the Extension files (matching ExtensionExport.tsx)
const EXTENSION_FILES = {
  'manifest.json': `{
  "manifest_version": 3,
  "name": "FocusGuard",
  "version": "1.0.0",
  "description": "Focus Mode with Activity Verification",
  "permissions": [
    "declarativeNetRequest",
    "storage",
    "alarms",
    "scripting",
    "tabs"
  ],
  "host_permissions": [
    "<all_urls>"
  ],
  "background": {
    "service_worker": "background.js"
  },
  "action": {
    "default_popup": "popup.html"
  },
  "content_scripts": [
    {
      "matches": ["<all_urls>"],
      "js": ["content.js"],
      "run_at": "document_idle"
    }
  ]
}`,
  'background.js': `// background.js
const BLOCKED_DOMAINS = [
  "instagram.com", "twitter.com", "reddit.com", "facebook.com", "tiktok.com"
];

chrome.runtime.onInstalled.addListener(() => {
  const rules = BLOCKED_DOMAINS.map((domain, index) => ({
    id: index + 1,
    priority: 1,
    action: { type: "redirect", redirect: { url: "https://focusguard-app.com/blocked" } },
    condition: { urlFilter: domain, resourceTypes: ["main_frame"] }
  }));

  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: rules.map(r => r.id),
    addRules: rules
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "START_SESSION") {
    console.log("Session Started: Blocking active");
    sendResponse({ status: "active" });
  } else if (message.type === "STOP_SESSION") {
    console.log("Session Stopped");
    sendResponse({ status: "idle" });
  }
});`,
  'content.js': `// content.js
console.log("FocusGuard Active");
document.addEventListener("visibilitychange", () => {
  chrome.runtime.sendMessage({
    type: "ACTIVITY_UPDATE",
    payload: {
      visible: document.visibilityState === "visible",
      url: window.location.href
    }
  });
});
setInterval(() => {
  const video = document.querySelector('video');
  if (video) {
    chrome.runtime.sendMessage({
      type: "VIDEO_STATUS",
      payload: {
        playing: !video.paused,
        muted: video.muted,
        currentTime: video.currentTime
      }
    });
  }
}, 5000);`,
  'popup.html': `<!DOCTYPE html>
<html>
  <head>
    <style>
      body { width: 300px; padding: 20px; font-family: sans-serif; background: #0f172a; color: white; }
      h1 { font-size: 18px; color: #38bdf8; }
      .status { padding: 10px; background: #1e293b; border-radius: 8px; margin-top: 10px; }
    </style>
  </head>
  <body>
    <h1>FocusGuard</h1>
    <div class="status">Status: <span id="status">Active</span></div>
    <p>Session controlled by main app.</p>
  </body>
</html>`
};

// Hardcoded file contents for the React App
const REACT_FILES = {
  'index.html': `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FocusGuard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              brand: {
                50: '#f0f9ff',
                100: '#e0f2fe',
                500: '#0ea5e9',
                600: '#0284c7',
                900: '#0c4a6e',
              },
              dark: {
                800: '#1e293b',
                900: '#0f172a',
                950: '#020617',
              }
            },
            animation: {
              'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
            }
          },
        },
      }
    </script>
    <style>
      ::-webkit-scrollbar { width: 8px; height: 8px; }
      ::-webkit-scrollbar-track { background: #1e293b; }
      ::-webkit-scrollbar-thumb { background: #475569; border-radius: 4px; }
      ::-webkit-scrollbar-thumb:hover { background: #64748b; }
    </style>
  </head>
  <body class="bg-dark-950 text-slate-200 antialiased overflow-x-hidden">
    <div id="root"></div>
    <script type="module" src="/index.tsx"></script>
  </body>
</html>`,

  'index.tsx': `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);`,
  
  // Note: For brevity in this simulation, we are only including key files. 
  // In a real export, you'd include everything from the current project.
  'README.md': `# FocusGuard Project

## How to run the Web Dashboard
1. \`npm install\`
2. \`npm start\`

## How to install the Chrome Extension
1. Go to the \`extension\` folder in this zip.
2. Open Chrome and navigate to \`chrome://extensions\`.
3. Enable "Developer mode" in the top right.
4. Click "Load unpacked" and select the \`extension\` folder.
`
};

export const DownloadSource: React.FC = () => {
  const handleDownload = async () => {
    const zip = new JSZip();
    const folder = zip.folder("FocusGuard-Project");
    
    // Add React App files
    Object.entries(REACT_FILES).forEach(([path, content]) => {
      folder?.file(path, content);
    });

    // Add Extension files in a subfolder
    const extFolder = folder?.folder("extension");
    Object.entries(EXTENSION_FILES).forEach(([path, content]) => {
      extFolder?.file(path, content);
    });

    const blob = await zip.generateAsync({ type: "blob" });
    saveAs(blob, "focusguard-full-project.zip");
  };

  return (
    <button 
      onClick={handleDownload}
      className="flex items-center gap-2 px-4 py-2 bg-brand-600 hover:bg-brand-500 text-white text-sm font-medium rounded-lg transition-colors shadow-lg shadow-brand-900/20"
    >
      <Package className="w-4 h-4" />
      Download Full Project
    </button>
  );
};