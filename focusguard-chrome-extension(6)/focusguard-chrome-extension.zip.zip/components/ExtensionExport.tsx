import React, { useState } from 'react';
import { ExtensionFile } from '../types';
import { Copy, Download, FolderArchive, AlertCircle } from 'lucide-react';
import JSZip from 'jszip';
import saveAs from 'file-saver';

const MANIFEST_JSON = `{
  "manifest_version": 3,
  "name": "FocusGuard",
  "version": "1.0.0",
  "description": "Focus Mode with Activity Verification",
  "permissions": [
    "declarativeNetRequest",
    "storage",
    "alarms",
    "scripting",
    "tabs"
  ],
  "host_permissions": [
    "<all_urls>"
  ],
  "background": {
    "service_worker": "background.js"
  },
  "action": {
    "default_popup": "popup.html"
  },
  "content_scripts": [
    {
      "matches": ["<all_urls>"],
      "js": ["content.js"],
      "run_at": "document_idle"
    }
  ]
}`;

const BACKGROUND_JS = `// background.js
const BLOCKED_DOMAINS = [
  "instagram.com", "twitter.com", "reddit.com", "facebook.com", "tiktok.com"
];

// Initialize blocking rules
chrome.runtime.onInstalled.addListener(() => {
  const rules = BLOCKED_DOMAINS.map((domain, index) => ({
    id: index + 1,
    priority: 1,
    action: { type: "redirect", redirect: { url: "https://focusguard-app.com/blocked" } },
    condition: { urlFilter: domain, resourceTypes: ["main_frame"] }
  }));

  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: rules.map(r => r.id),
    addRules: rules
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "START_SESSION") {
    // Enable blocking rules
    console.log("Session Started: Blocking active");
    sendResponse({ status: "active" });
  } else if (message.type === "STOP_SESSION") {
    // Ideally disable blocking rules here
    console.log("Session Stopped");
    sendResponse({ status: "idle" });
  }
});`;

const CONTENT_JS = `// content.js
console.log("FocusGuard Active");

// Listen for visibility changes to detect if user is actively viewing the tab
document.addEventListener("visibilitychange", () => {
  chrome.runtime.sendMessage({
    type: "ACTIVITY_UPDATE",
    payload: {
      visible: document.visibilityState === "visible",
      url: window.location.href
    }
  });
});

// Check for Video Elements
setInterval(() => {
  const video = document.querySelector('video');
  if (video) {
    chrome.runtime.sendMessage({
      type: "VIDEO_STATUS",
      payload: {
        playing: !video.paused,
        muted: video.muted,
        currentTime: video.currentTime
      }
    });
  }
}, 5000);
`;

const POPUP_HTML = `<!DOCTYPE html>
<html>
  <head>
    <style>
      body { width: 300px; padding: 20px; font-family: sans-serif; background: #0f172a; color: white; }
      h1 { font-size: 18px; color: #38bdf8; }
      .status { padding: 10px; background: #1e293b; border-radius: 8px; margin-top: 10px; }
    </style>
  </head>
  <body>
    <h1>FocusGuard</h1>
    <div class="status">
      Status: <span id="status">Active</span>
    </div>
    <p>Session controlled by main app.</p>
  </body>
</html>`;

const VSCODE_EXTENSION_JS = `// extension.js (VS Code)
const vscode = require('vscode');
const axios = require('axios'); // User needs to npm install axios

function activate(context) {
    console.log('FocusGuard VS Code Tracker Active');

    let lastTypeTime = 0;
    const DEBOUNCE = 2000;

    let disposable = vscode.workspace.onDidChangeTextDocument((event) => {
        const now = Date.now();
        if (now - lastTypeTime > DEBOUNCE) {
            lastTypeTime = now;
            // Send heartbeat to local server or main app
            // In a real app, this endpoint would be your backend
            // axios.post('http://localhost:3000/api/heartbeat', { timestamp: now });
            console.log('Typing detected...');
        }
    });

    context.subscriptions.push(disposable);
}

function deactivate() {}

module.exports = {
    activate,
    deactivate
}`;

const files: ExtensionFile[] = [
  { name: 'manifest.json', content: MANIFEST_JSON, language: 'json' },
  { name: 'background.js', content: BACKGROUND_JS, language: 'javascript' },
  { name: 'content.js', content: CONTENT_JS, language: 'javascript' },
  { name: 'popup.html', content: POPUP_HTML, language: 'html' },
  { name: 'vscode-extension.js', content: VSCODE_EXTENSION_JS, language: 'javascript' },
];

export const ExtensionExport: React.FC = () => {
  const [activeFile, setActiveFile] = useState<string>(files[0].name);

  const currentContent = files.find(f => f.name === activeFile)?.content || '';

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    alert('Code copied to clipboard!');
  };

  const handleDownload = async () => {
    const zip = new JSZip();
    
    // Create a folder INSIDE the zip to avoid "loose file" confusion when extracting
    const folder = zip.folder("FocusGuardExtension");

    if (folder) {
        // Add extension files to the folder
        files.forEach(file => {
        // Exclude vscode extension from the chrome extension folder to avoid confusion
        if (file.name !== 'vscode-extension.js') {
            folder.file(file.name, file.content);
        }
        });
        
        // Add instruction
        folder.file("README.txt", "1. Open chrome://extensions/\n2. Enable Developer Mode (top right)\n3. Click 'Load unpacked' and select THIS folder (FocusGuardExtension).");
    }

    const blob = await zip.generateAsync({type:"blob"});
    saveAs(blob, "focusguard-chrome-extension.zip");
  };

  return (
    <div className="bg-dark-900 border border-slate-700 rounded-lg overflow-hidden shadow-2xl mt-8">
      <div className="bg-dark-800 p-4 border-b border-slate-700 flex justify-between items-center flex-wrap gap-4">
        <div className="flex items-center gap-2">
          <FolderArchive className="text-brand-500 w-5 h-5" />
          <h2 className="text-lg font-semibold text-white">Focus Extension Source</h2>
        </div>
        <button 
          onClick={handleDownload}
          className="text-white bg-brand-600 hover:bg-brand-500 px-4 py-2 rounded-lg transition-colors text-sm font-medium flex items-center gap-2 shadow-lg shadow-brand-900/20"
        >
           <Download className="w-4 h-4" /> Download Extension ZIP
        </button>
      </div>
      
      {/* Help Alert */}
      <div className="bg-blue-900/20 p-4 border-b border-slate-800 flex items-start gap-3">
         <AlertCircle className="w-5 h-5 text-brand-400 mt-0.5 shrink-0" />
         <div className="text-sm text-slate-300">
            <p className="font-bold text-brand-200 mb-1">How to fix "Manifest file is missing" error:</p>
            <ol className="list-decimal pl-4 space-y-1 text-slate-400">
               <li>Click the <strong>Download Extension ZIP</strong> button above.</li>
               <li><strong>Extract/Unzip</strong> the downloaded file.</li>
               <li>In Chrome Extensions, click <strong>Load Unpacked</strong>.</li>
               <li>Select the folder named <strong>FocusGuardExtension</strong> that was just extracted (it contains <code>manifest.json</code>).</li>
            </ol>
         </div>
      </div>

      <div className="flex flex-col md:flex-row h-[500px]">
        {/* Sidebar */}
        <div className="w-full md:w-64 bg-dark-950 border-r border-slate-800 overflow-y-auto">
          {files.map(file => (
            <button
              key={file.name}
              onClick={() => setActiveFile(file.name)}
              className={`w-full text-left px-4 py-3 text-sm font-mono border-l-2 transition-colors ${
                activeFile === file.name
                  ? 'border-brand-500 bg-slate-800 text-brand-400'
                  : 'border-transparent text-slate-400 hover:bg-slate-900'
              }`}
            >
              {file.name}
            </button>
          ))}
        </div>

        {/* Code Editor View */}
        <div className="flex-1 relative bg-[#0d1117] overflow-hidden flex flex-col">
          <div className="absolute top-4 right-4 z-10">
            <button 
              onClick={handleCopy}
              className="p-2 bg-slate-800 rounded hover:bg-slate-700 text-slate-300 transition-colors"
              title="Copy to clipboard"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>
          <pre className="p-6 text-sm font-mono overflow-auto h-full text-slate-300 leading-relaxed">
            <code>{currentContent}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};