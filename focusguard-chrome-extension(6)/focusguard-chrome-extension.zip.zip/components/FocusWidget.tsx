import React from 'react';
import { SessionStatus, ActivityType } from '../types';
import { Timer, Zap, AlertCircle } from 'lucide-react';

interface FocusWidgetProps {
  status: SessionStatus;
  activityType: ActivityType;
  seconds: number;
  message?: string;
}

export const FocusWidget: React.FC<FocusWidgetProps> = ({ status, activityType, seconds, message }) => {
  if (status === SessionStatus.IDLE) return null;

  const formatTime = (totalSeconds: number) => {
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const getStatusColor = () => {
    switch (status) {
      case SessionStatus.ACTIVE: return 'bg-brand-600 border-brand-400';
      case SessionStatus.PAUSED: return 'bg-yellow-600 border-yellow-400';
      case SessionStatus.BLOCKED: return 'bg-red-600 border-red-400';
      default: return 'bg-slate-700';
    }
  };

  return (
    <div className={`fixed bottom-6 right-6 z-50 p-4 rounded-2xl shadow-2xl border-t shadow-black/50 backdrop-blur-md transition-all duration-300 w-80 ${getStatusColor()} text-white`}>
      <div className="flex justify-between items-start mb-2">
        <div className="flex items-center gap-2">
          {status === SessionStatus.ACTIVE ? <Zap className="w-5 h-5 animate-pulse text-yellow-300" /> : <Timer className="w-5 h-5" />}
          <span className="font-bold text-lg tracking-wide">Focus Mode</span>
        </div>
        <div className="text-2xl font-mono font-bold">{formatTime(seconds)}</div>
      </div>
      
      <div className="flex flex-col gap-1">
        <div className="flex items-center justify-between text-xs uppercase tracking-wider font-semibold opacity-80">
          <span>Status: {status}</span>
          <span>Activity: {activityType}</span>
        </div>
        
        {message && (
           <div className="mt-2 text-sm bg-black/20 p-2 rounded flex items-start gap-2">
             <AlertCircle className="w-4 h-4 min-w-[16px] mt-0.5" />
             <span className="leading-tight">{message}</span>
           </div>
        )}
      </div>
    </div>
  );
};