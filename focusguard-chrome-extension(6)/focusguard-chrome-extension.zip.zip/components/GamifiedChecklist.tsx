import React, { useEffect, useState } from 'react';
import { CheckCircle2, Circle, Lock, Trophy, Zap } from 'lucide-react';
import { AutoTask } from '../types';

interface GamifiedChecklistProps {
  tasks: AutoTask[];
  score: number;
}

export const GamifiedChecklist: React.FC<GamifiedChecklistProps> = ({ tasks, score }) => {
  // Calculate progress for bar
  const progress = (tasks.filter(t => t.completed).length / tasks.length) * 100;

  return (
    <div className="bg-dark-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
        <Trophy className="w-32 h-32" />
      </div>

      <div className="flex items-center justify-between mb-6 relative z-10">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <Zap className="text-yellow-400 w-5 h-5 fill-current" />
          Mission Objectives
        </h3>
        <div className="bg-slate-800 px-3 py-1 rounded-full border border-slate-700">
          <span className="text-sm text-brand-400 font-mono font-bold">XP: {score}</span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-800 h-2 rounded-full mb-6 overflow-hidden">
        <div 
          className="bg-gradient-to-r from-brand-500 to-green-400 h-full transition-all duration-1000 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="space-y-3 relative z-10">
        {tasks.map((task) => (
          <TaskItem key={task.id} task={task} />
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-slate-800 text-center">
        <p className="text-xs text-slate-500 flex items-center justify-center gap-1">
          <Lock className="w-3 h-3" />
          Tasks complete automatically based on verified activity
        </p>
      </div>
    </div>
  );
};

const TaskItem: React.FC<{ task: AutoTask }> = ({ task }) => {
  const [justCompleted, setJustCompleted] = useState(false);

  useEffect(() => {
    if (task.completed) {
      setJustCompleted(true);
      const timer = setTimeout(() => setJustCompleted(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [task.completed]);

  return (
    <div 
      className={`
        flex items-center justify-between p-3 rounded-xl border transition-all duration-500
        ${task.completed 
          ? 'bg-green-900/20 border-green-500/50 scale-[1.02] shadow-[0_0_15px_rgba(34,197,94,0.2)]' 
          : 'bg-slate-900 border-slate-800 opacity-80'
        }
      `}
    >
      <div className="flex items-center gap-3">
        <div className="relative">
          {task.completed ? (
             <div className={`${justCompleted ? 'animate-bounce' : ''}`}>
               <CheckCircle2 className="w-6 h-6 text-green-400 fill-green-900" />
             </div>
          ) : (
             <Circle className="w-6 h-6 text-slate-600" />
          )}
        </div>
        <div>
          <h4 className={`font-medium text-sm transition-colors ${task.completed ? 'text-green-200' : 'text-slate-300'}`}>
            {task.label}
          </h4>
          <span className="text-xs text-slate-500 block">{task.requirement}</span>
        </div>
      </div>
      
      {/* Hidden checkbox for accessibility/structure, but strictly readOnly */}
      <input 
        type="checkbox" 
        checked={task.completed} 
        readOnly 
        className="hidden" 
      />
    </div>
  );
};
