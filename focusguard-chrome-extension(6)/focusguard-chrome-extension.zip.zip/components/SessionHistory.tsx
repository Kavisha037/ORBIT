import React from 'react';
import { SessionRecord, ActivityType } from '../types';
import { History, PlayCircle, Code2, Calendar } from 'lucide-react';

interface SessionHistoryProps {
  history: SessionRecord[];
}

export const SessionHistory: React.FC<SessionHistoryProps> = ({ history }) => {
  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}m ${s}s`;
  };

  return (
    <div className="bg-dark-900 border border-slate-800 rounded-2xl p-6 h-full">
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <History className="w-5 h-5 text-brand-500" />
        Session History
      </h3>

      {history.length === 0 ? (
        <div className="text-center py-12 text-slate-500">
          <Calendar className="w-12 h-12 mx-auto mb-3 opacity-20" />
          <p>No sessions recorded yet.</p>
          <p className="text-xs">Complete a session to see it here.</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
          {history.map((record) => (
            <div key={record.id} className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800/50">
              <div className="flex items-center gap-4">
                <div className={`p-2 rounded-full ${record.type === ActivityType.VIDEO ? 'bg-brand-900/30 text-brand-400' : 'bg-purple-900/30 text-purple-400'}`}>
                  {record.type === ActivityType.VIDEO ? <PlayCircle className="w-5 h-5" /> : <Code2 className="w-5 h-5" />}
                </div>
                <div>
                  <div className="font-bold text-slate-200">{record.type === ActivityType.VIDEO ? 'Video Learning' : 'Coding Session'}</div>
                  <div className="text-xs text-slate-500">{record.date}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xl font-mono font-bold text-white">{formatTime(record.duration)}</div>
                <div className="text-xs font-bold text-green-400">+{record.score} XP</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
