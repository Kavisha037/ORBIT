import React, { useRef, useEffect, useState } from 'react';
import Webcam from 'react-webcam';
import { Camera, UserX, UserCheck, AlertTriangle } from 'lucide-react';
import { FACE_CHECK_INTERVAL_MS } from '../constants';

interface WebcamVerifierProps {
  onVerificationUpdate: (isVerified: boolean) => void;
  isActive: boolean;
}

export const WebcamVerifier: React.FC<WebcamVerifierProps> = ({ onVerificationUpdate, isActive }) => {
  const webcamRef = useRef<Webcam>(null);
  const [hasPermission, setHasPermission] = useState<boolean>(false);
  const [faceStatus, setFaceStatus] = useState<'DETECTED' | 'MISSING' | 'OFF'>('OFF');
  const [simulatedLookAway, setSimulatedLookAway] = useState(false);

  useEffect(() => {
    if (!isActive) {
      setFaceStatus('OFF');
      onVerificationUpdate(true); // Don't block if feature is off
      return;
    }

    const interval = setInterval(() => {
      // Simulation Logic: In a real app with face-api.js, we would detect here.
      // For this demo, we check if camera is loaded and not "simulating look away".
      if (webcamRef.current && webcamRef.current.video?.readyState === 4 && !simulatedLookAway) {
        setFaceStatus('DETECTED');
        onVerificationUpdate(true);
      } else {
        setFaceStatus('MISSING');
        onVerificationUpdate(false);
      }
    }, 2000); // Check every 2 seconds for smoother UI feedback than 30s

    return () => clearInterval(interval);
  }, [isActive, simulatedLookAway, onVerificationUpdate]);

  const handleUserMedia = () => {
    setHasPermission(true);
  };

  const handleUserMediaError = () => {
    setHasPermission(false);
    alert("Camera permission denied. Face verification disabled.");
  };

  return (
    <div className="relative group bg-black rounded-lg overflow-hidden border border-slate-700 w-full max-w-xs mx-auto shadow-lg">
      <div className="absolute top-2 left-2 z-10 bg-black/50 backdrop-blur px-2 py-1 rounded text-xs font-mono text-white flex items-center gap-1">
        <Camera className="w-3 h-3" />
        {isActive ? 'VERIFICATION ON' : 'IDLE'}
      </div>

      {isActive ? (
        <>
          <Webcam
            ref={webcamRef}
            audio={false}
            height={200}
            width={320}
            className={`w-full h-48 object-cover transition-opacity duration-300 ${simulatedLookAway ? 'opacity-50 grayscale' : 'opacity-100'}`}
            onUserMedia={handleUserMedia}
            onUserMediaError={handleUserMediaError}
            mirrored
          />
          
          <div className="absolute bottom-0 w-full p-2 bg-gradient-to-t from-black/90 to-transparent flex justify-between items-center">
             <div className="flex items-center gap-2">
                {faceStatus === 'DETECTED' ? (
                  <span className="text-green-400 text-xs font-bold flex items-center gap-1">
                    <UserCheck className="w-3 h-3" /> FACE DETECTED
                  </span>
                ) : (
                  <span className="text-red-500 text-xs font-bold flex items-center gap-1 animate-pulse">
                    <UserX className="w-3 h-3" /> NO FACE
                  </span>
                )}
             </div>
          </div>
          
          {/* Simulation Controls for Demo */}
          <div className="p-2 bg-slate-900 border-t border-slate-800">
             <label className="flex items-center space-x-2 text-xs text-slate-400 cursor-pointer select-none">
                <input 
                  type="checkbox" 
                  checked={simulatedLookAway} 
                  onChange={(e) => setSimulatedLookAway(e.target.checked)}
                  className="rounded bg-slate-800 border-slate-700 text-brand-500 focus:ring-offset-dark-900"
                />
                <span>Simulate "Look Away" / Absence</span>
             </label>
          </div>
        </>
      ) : (
        <div className="h-48 flex flex-col items-center justify-center bg-slate-900 text-slate-500">
          <UserCheck className="w-12 h-12 mb-2 opacity-20" />
          <p className="text-xs">Camera Inactive</p>
        </div>
      )}
    </div>
  );
};