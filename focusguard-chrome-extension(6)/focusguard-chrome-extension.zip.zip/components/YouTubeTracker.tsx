import React, { useRef, useState, useEffect } from 'react';
import YouTube, { YouTubeProps } from 'react-youtube';
import { AlertTriangle, Play, Pause, Volume2, VolumeX, EyeOff, Loader2 } from 'lucide-react';

interface YouTubeTrackerProps {
  videoId: string;
  onActivityUpdate: (isProductive: boolean) => void;
  isActive: boolean;
}

export const YouTubeTracker: React.FC<YouTubeTrackerProps> = ({ videoId, onActivityUpdate, isActive }) => {
  const [playerState, setPlayerState] = useState<number>(-1);
  const [isMuted, setIsMuted] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const playerRef = useRef<any>(null);

  // Anti-Cheat: Visibility Check
  useEffect(() => {
    const handleVisibilityChange = () => {
      const visible = document.visibilityState === 'visible';
      setIsVisible(visible);
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  // Programmatic Control: Pause/Play based on session active state
  useEffect(() => {
    if (playerRef.current && typeof playerRef.current.pauseVideo === 'function') {
      // If session is NOT active (e.g. paused by face check), pause video to enforce focus
      if (!isActive && playerState === 1) { 
        playerRef.current.pauseVideo();
      } 
      // If session returns to ACTIVE and video is paused, auto-resume for seamless experience
      else if (isActive && playerState === 2) {
        playerRef.current.playVideo();
      }
    }
  }, [isActive, playerState]);

  // Check productivity loop
  useEffect(() => {
    const checkProductivity = () => {
      // YouTube Player States: -1 (Unstarted), 0 (Ended), 1 (Playing), 2 (Paused), 3 (Buffering), 5 (Video cued)
      // Rule: Must be playing (1) to count as productive. 
      const isPlaying = playerState === 1;
      const isProductive = isPlaying && !isMuted && isVisible;
      onActivityUpdate(isProductive);
    };

    checkProductivity();
  }, [playerState, isMuted, isVisible, onActivityUpdate]);

  const onReady: YouTubeProps['onReady'] = async (event) => {
    playerRef.current = event.target;
    try {
      // Initial checks
      const muted = await event.target.isMuted();
      setIsMuted(muted);
      
      // If session started as active, ensure video plays
      if (isActive) {
        event.target.playVideo();
      }
    } catch (error) {
      console.error("Error accessing player API:", error);
    }
  };

  const onStateChange: YouTubeProps['onStateChange'] = async (event) => {
    setPlayerState(event.data);
    // Refresh mute status on state change
    if (playerRef.current) {
      try {
        const muted = await playerRef.current.isMuted();
        setIsMuted(muted);
      } catch (e) {
        console.error("Error checking mute status:", e);
      }
    }
  };

  // Poll for mute status & volume specifically (API events don't always catch volume slider changes)
  useEffect(() => {
    const interval = setInterval(async () => {
      if (playerRef.current) {
        try {
          const isMutedVal = await playerRef.current.isMuted();
          const volumeVal = await playerRef.current.getVolume();
          // Consider volume 0 as muted
          const muted = isMutedVal || volumeVal === 0;
          if (muted !== isMuted) setIsMuted(muted);
        } catch (error) {}
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [isMuted]);

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="relative aspect-video rounded-xl overflow-hidden shadow-2xl border-2 border-slate-800 bg-black">
        <YouTube
          videoId={videoId}
          className="w-full h-full"
          iframeClassName="w-full h-full"
          onReady={onReady}
          onStateChange={onStateChange}
          opts={{
            playerVars: {
              autoplay: 1,
              controls: 1,
              modestbranding: 1,
              rel: 0,
            },
          }}
        />
        
        {/* Overlay warnings */}
        {(!isVisible || (playerState === 1 && isMuted)) && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center text-center p-6 z-20 backdrop-blur-sm transition-opacity duration-300">
             <AlertTriangle className="w-12 h-12 text-yellow-500 mb-4 animate-bounce" />
             <h3 className="text-xl font-bold text-white mb-2">Productivity Paused</h3>
             <ul className="text-slate-300 text-sm space-y-2">
                {!isVisible && <li className="flex items-center justify-center gap-2"><EyeOff className="w-4 h-4"/> Tab hidden (Background play restricted)</li>}
                {isMuted && <li className="flex items-center justify-center gap-2"><VolumeX className="w-4 h-4"/> Audio muted (Listening required)</li>}
             </ul>
          </div>
        )}
      </div>

      {/* Status Bar */}
      <div className="mt-4 flex items-center justify-between p-4 bg-slate-900 rounded-lg border border-slate-800">
        <div className="flex items-center gap-4">
          <div className={`flex items-center gap-2 ${playerState === 1 ? 'text-green-400' : 'text-slate-500'}`}>
            {playerState === 1 ? <Play className="w-4 h-4 fill-current" /> : playerState === 3 ? <Loader2 className="w-4 h-4 animate-spin" /> : <Pause className="w-4 h-4 fill-current" />}
            <span className="text-sm font-medium">
              {playerState === 1 ? 'Playing' : playerState === 3 ? 'Buffering' : 'Paused'}
            </span>
          </div>
          <div className={`flex items-center gap-2 ${!isMuted ? 'text-green-400' : 'text-red-400'}`}>
            {!isMuted ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="text-sm font-medium">{!isMuted ? 'Audio Active' : 'Muted'}</span>
          </div>
        </div>
        <div className={`px-2 py-1 rounded text-xs font-bold ${isVisible ? 'bg-brand-900 text-brand-200' : 'bg-red-900 text-red-200'}`}>
          {isVisible ? 'TAB ACTIVE' : 'TAB HIDDEN'}
        </div>
      </div>
    </div>
  );
};