import { BlockedSite } from './types';

export const BLOCKED_SITES: BlockedSite[] = [
  { id: '1', url: 'instagram.com' },
  { id: '2', url: 'twitter.com' },
  { id: '3', url: 'youtube.com/shorts' },
  { id: '4', url: 'reddit.com' },
  { id: '5', url: 'facebook.com' },
  { id: '6', url: 'tiktok.com' },
];

export const CODING_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes
export const FACE_CHECK_INTERVAL_MS = 30000; // 30 seconds

export const GEMINI_MOTIVATION_PROMPT = `
You are a strict but encouraging study coach. 
The user has been focusing for a while but might be getting tired.
Give a one-sentence motivating quote or tip to keep them going.
Focus on discipline and the value of deep work.
`;