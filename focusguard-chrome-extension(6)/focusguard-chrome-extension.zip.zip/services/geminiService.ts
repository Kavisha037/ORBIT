import { GoogleGenAI } from "@google/genai";
import { GEMINI_MOTIVATION_PROMPT } from '../constants';

export const getMotivation = async (): Promise<string> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) return "Keep pushing! You're doing great.";

    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: GEMINI_MOTIVATION_PROMPT,
    });

    return response.text || "Focus is the key to mastery.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Stay focused. Every second counts.";
  }
};