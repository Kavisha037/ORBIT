export enum SessionStatus {
  IDLE = 'IDLE',
  ACTIVE = 'ACTIVE',
  PAUSED = 'PAUSED',
  BLOCKED = 'BLOCKED'
}

export enum ActivityType {
  VIDEO = 'VIDEO',
  CODING = 'CODING',
  READING = 'READING',
  IDLE = 'IDLE'
}

export interface SessionMetrics {
  startTime: number | null;
  totalFocusTime: number; // in seconds
  distractionsBlocked: number;
  currentStreak: number;
}

export interface VerificationStatus {
  faceDetected: boolean;
  videoPlaying: boolean;
  videoMuted: boolean;
  tabHidden: boolean;
  codingHeartbeat: number; // timestamp
}

export interface BlockedSite {
  id: string;
  url: string;
}

export interface ExtensionFile {
  name: string;
  content: string;
  language: string;
}

export interface SessionRecord {
  id: string;
  date: string;
  duration: number;
  type: ActivityType;
  score: number;
}

export interface AutoTask {
  id: string;
  label: string;
  completed: boolean;
  requirement: string; // Description for UI
}