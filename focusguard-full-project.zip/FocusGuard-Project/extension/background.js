// background.js
const BLOCKED_DOMAINS = ["instagram.com", "twitter.com", "reddit.com", "facebook.com", "tiktok.com", "youtube.com/shorts"];
async function updateBlockingRules(enable) {
  const rules = BLOCKED_DOMAINS.map((domain, index) => ({
    id: index + 1,
    priority: 1,
    action: { type: "redirect", redirect: { extensionPath: "/blocked.html" } },
    condition: { urlFilter: domain, resourceTypes: ["main_frame"] }
  }));
  const ruleIds = rules.map(r => r.id);
  if (enable) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: ruleIds, addRules: rules });
  } else {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: ruleIds, addRules: [] });
  }
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ sessionActive: false });
  updateBlockingRules(false);
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "START_SESSION") {
    chrome.storage.local.set({ sessionActive: true });
    updateBlockingRules(true);
    if (message.data?.youtube) { chrome.tabs.create({ url: message.data.youtube }); }
    sendResponse({ status: "active" });
  } else if (message.type === "STOP_SESSION") {
    chrome.storage.local.set({ sessionActive: false });
    updateBlockingRules(false);
    sendResponse({ status: "idle" });
  } else if (message.type === "CHECK_STATUS") {
    chrome.storage.local.get(['sessionActive'], (result) => { sendResponse({ status: result.sessionActive ? "active" : "idle" }); });
    return true;
  }
  else if (message.action === "GET_COURSE") {
    fetch("http://localhost:3000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ course: message.course })
    })
      .then(res => res.json())
      .then(data => {
        if (data.youtube) chrome.tabs.create({ url: data.youtube });
        sendResponse(data);
      })
      .catch(() => sendResponse({ error: true }));
    return true;
  }
});