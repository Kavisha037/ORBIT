// content.js
console.log("FocusGuard Loaded");
window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  if (event.data.type === "FOCUS_GUARD_START") chrome.runtime.sendMessage({ type: "START_SESSION", data: event.data.data });
  if (event.data.type === "FOCUS_GUARD_STOP") chrome.runtime.sendMessage({ type: "STOP_SESSION" });
});